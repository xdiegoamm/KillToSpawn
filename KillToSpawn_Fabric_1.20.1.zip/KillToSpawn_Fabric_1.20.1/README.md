# Kill To Spawn — Fabric 1.20.1

Client-side Fabric mod.

## What it does
When the client receives a server/game message that looks like a player death message and the
message identifies your own username as the killer, it automatically sends:

`/spawn`

Default toggle key: **K**

Commands:
- `/killspawn on`
- `/killspawn off`
- `/killspawn toggle`

## Important
The server must allow `/spawn`. If your server uses `/hub` or another command, change:

`client.player.networkHandler.sendChatCommand("spawn");`

to the command you need, for example `"hub"`.

The kill detector is intentionally conservative. It checks for your username plus common
English/Spanish death/kill words. Some PvP servers use custom kill messages; if yours does not
match, send me an example of the exact message that appears after you kill someone and I can
adapt the detector.

## Build
Requires Java 17 and Gradle.

Run:
`gradlew build`

The finished JAR will be in:
`build/libs/`

Requires Fabric API 0.92.2+1.20.1.
